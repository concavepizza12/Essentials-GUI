package me.concave_pizza12.gui.events;

import java.util.Collection;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class ClickEvent implements Listener {
	
	@EventHandler
	public void clickEvent(InventoryClickEvent e) {
		Player player = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory().getTitle().equalsIgnoreCase(ChatColor.GOLD + "Essentials GUI")) {
			
			switch(e.getCurrentItem().getType()) {
				case TNT:
					player.closeInventory();
					player.setHealth(0.0);
					player.sendMessage("You have killed yourself!");
					break;
				case COOKED_BEEF:
					player.closeInventory();
					player.setFoodLevel(20);
					player.setHealth(20);
					player.sendMessage("You have been healed!");
					break;
				case IRON_SWORD:
					player.closeInventory();
					player.getInventory().addItem(new ItemStack(Material.IRON_SWORD));
					player.sendMessage("You have been given a sword!");
					break;
				case ENDER_PEARL:
					player.closeInventory();
					player.setGameMode(GameMode.CREATIVE);
					player.sendMessage("You are now in creative!");
					break;
				case PORK:
					player.closeInventory();
					player.setGameMode(GameMode.SURVIVAL);
					player.sendMessage("You are now in survival!");
					break;
				case RAW_BEEF:
					player.closeInventory();
					player.setGameMode(GameMode.ADVENTURE);
					player.sendMessage("You are now in adventure!");
					break;
				case FEATHER:
					player.closeInventory();
					player.setAllowFlight(true);
					player.setFlying(true);
					player.sendMessage("Fly like a bird!");
					break;
				case BEDROCK:
					player.closeInventory();
					player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 100000, 1));
					player.getInventory().addItem(new ItemStack(Material.MILK_BUCKET));
					player.sendMessage("You are now invisible!");
					break;
				case BARRIER:
					player.closeInventory();
					break;
			}
			
			e.setCancelled(true);
		}
		
		
	}
	
}
