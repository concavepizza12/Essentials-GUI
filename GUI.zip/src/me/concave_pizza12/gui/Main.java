package me.concave_pizza12.gui;

import org.bukkit.plugin.java.JavaPlugin;

import me.concave_pizza12.gui.commands.gui;
import me.concave_pizza12.gui.events.ClickEvent;

public class Main extends JavaPlugin{
	
	@Override
	public void onEnable() {
		
		getCommand("gui").setExecutor(new gui());
		
		getServer().getPluginManager().registerEvents(new ClickEvent(), this);
		
	}
	
}
