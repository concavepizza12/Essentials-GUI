package me.concave_pizza12.gui.commands;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;


public class gui implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		
		if(sender instanceof Player) {
			Player player = (Player) sender;
			
			Inventory gui = Bukkit.createInventory(player, 9, ChatColor.GOLD + "Essentials GUI");
			
			ItemStack kill = new ItemStack(Material.TNT);
			ItemStack heal = new ItemStack(Material.COOKED_BEEF);
			ItemStack sword = new ItemStack(Material.IRON_SWORD);
			ItemStack fly = new ItemStack(Material.FEATHER);
			ItemStack gmc = new ItemStack(Material.ENDER_PEARL);
			ItemStack gms = new ItemStack(Material.PORK);
			ItemStack gma = new ItemStack(Material.RAW_BEEF);
			ItemStack van = new ItemStack(Material.BEDROCK);
			ItemStack exit = new ItemStack(Material.BARRIER);
			
			ItemMeta kill_meta = kill.getItemMeta();
			kill_meta.setDisplayName(ChatColor.BLUE + "Kill");
			ArrayList<String> kill_lore = new ArrayList<>();
			kill_lore.add(ChatColor.RED + "Kills you!");
			kill_meta.setLore(kill_lore);
			kill.setItemMeta(kill_meta);
			
			ItemMeta heal_meta = heal.getItemMeta();
			heal_meta.setDisplayName(ChatColor.GREEN + "Heal");
			ArrayList<String> heal_lore = new ArrayList<>();
			heal_lore.add(ChatColor.RED + "Feeds you!");
			heal_meta.setLore(heal_lore);
			heal.setItemMeta(heal_meta);
			
			ItemMeta sword_meta = sword.getItemMeta();
			sword_meta.setDisplayName(ChatColor.BLUE + "Sword");
			ArrayList<String> sword_lore = new ArrayList<>();
			sword_lore.add(ChatColor.RED + "Give you a sword!");
			sword_meta.setLore(sword_lore);
			sword.setItemMeta(sword_meta);
			
			ItemMeta fly_meta = fly.getItemMeta();
			fly_meta.setDisplayName(ChatColor.BLUE + "Fly");
			ArrayList<String> fly_lore = new ArrayList<>();
			fly_lore.add(ChatColor.RED + "Lets you fly like a bird!");
			fly_meta.setLore(fly_lore);
			fly.setItemMeta(fly_meta);
			
			ItemMeta gmc_meta = gmc.getItemMeta();
			gmc_meta.setDisplayName(ChatColor.BLUE + "Creative");
			ArrayList<String> gmc_lore = new ArrayList<>();
			gmc_lore.add(ChatColor.RED + "Turns you to creative!");
			gmc_meta.setLore(gmc_lore);
			gmc.setItemMeta(gmc_meta);
			
			ItemMeta gms_meta = gms.getItemMeta();
			gms_meta.setDisplayName(ChatColor.BLUE + "Survival");
			ArrayList<String> gms_lore = new ArrayList<>();
			gms_lore.add(ChatColor.RED + "Turns you to survival!");
			gms_meta.setLore(gms_lore);
			gms.setItemMeta(gms_meta);
			
			ItemMeta gma_meta = gma.getItemMeta();
			gma_meta.setDisplayName(ChatColor.BLUE + "Adventure");
			ArrayList<String> gma_lore = new ArrayList<>();
			gma_lore.add(ChatColor.RED + "Turns you to adventure!");
			gma_meta.setLore(gma_lore);
			gma.setItemMeta(gma_meta);
			
			ItemMeta van_meta = van.getItemMeta();
			van_meta.setDisplayName(ChatColor.BLUE + "Vanish");
			ArrayList<String> van_lore = new ArrayList<>();
			van_lore.add(ChatColor.RED + "Makes you inisible!");
			van_meta.setLore(van_lore);
			van.setItemMeta(van_meta);
			
			ItemMeta exit_meta = exit.getItemMeta();
			exit_meta.setDisplayName(ChatColor.BLUE + "Exit");
			ArrayList<String> exit_lore = new ArrayList<>();
			exit_lore.add(ChatColor.RED + "Exits the GUI!");
			exit_meta.setLore(exit_lore);
			exit.setItemMeta(exit_meta);
			
			ItemStack[] menu_items = {kill, heal, sword, gmc, gms, gma, fly, van, exit};
			gui.setContents(menu_items);
			player.openInventory(gui);
		}
		
		return true;
	}
	
}
